#pragma once
#include "_components.hh"

namespace Editor {
	void Render(string statusbar, vector <string>& fbuf, size_t scrollY, size_t curx, size_t cury);
};
