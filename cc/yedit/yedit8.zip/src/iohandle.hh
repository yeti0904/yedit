#pragma once
#include "_components.hh"

namespace IOHandle {
	void SetTermTitle(const string& title);
	void Init();
	void Exit();
};
