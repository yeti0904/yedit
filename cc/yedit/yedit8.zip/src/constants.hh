#pragma once

#define APP_NAME "yedit b8.0"