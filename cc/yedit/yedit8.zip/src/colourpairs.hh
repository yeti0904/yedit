#pragma once

#define COLOUR_PAIR_EDITOR 1
#define COLOUR_PAIR_BAR    2
#define COLOUR_PAIR_CURSOR 3
